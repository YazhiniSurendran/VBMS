# c#
voice based email sender for blind using c# and mini voice bot

this is static apllication for visually challenged people, 

In this application we took group of users as sample, those details is stored in list such as emailid and name,
 
By using speech recongition of Microsoft speech library , application will recognition speech ,

one of the user from group can send mail to other users with in the group through speech,

and next part of application is mini voice bot, it can respond based upon user queries , this is done using microsoft speech Synthesis,

#Drawbacks:-

allow to send mails within a group,
Dictionary is not used,

#we overcome the drawbacks in next updates,

#How to use Applcation:-
 Form1.cs -> consist main interface from here u ccan navigate for mail sender or mini voicebot
 form2.cs-> mail sender
 form3.cs->voice bot

OUTPUT:-

![speech1](https://user-images.githubusercontent.com/21276406/29305824-5297ef80-81b8-11e7-98af-694ae1cc8945.png)


![speech2](https://user-images.githubusercontent.com/21276406/29305835-5c53f320-81b8-11e7-94a6-909c63a0c2a0.png)


![speech3](https://user-images.githubusercontent.com/21276406/29305846-646a21f6-81b8-11e7-9f7e-9b18c213a993.png)

